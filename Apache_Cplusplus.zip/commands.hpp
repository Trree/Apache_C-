#ifndef MOD_PASSAUTH_COMMANDS_HPP_
#define MOD_PASSAUTH_COMMANDS_HPP_

#include "httpd.h"
#include "http_config.h"

namespace mod_passauth {

extern const command_rec directives[];

} /* namespace mod_passauth */

#endif /* MOD_PASSAUTH_COMMANDS_HPP_ */
