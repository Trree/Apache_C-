#ifndef MOD_ACL_LOCALDB_H_
#define MOD_ACL_LOCALDB_H_

#include "httpd.h"
#include "http_config.h"

#ifdef __cplusplus
extern "C" {
#endif

extern module AP_MODULE_DECLARE_DATA passauth_module;

#ifdef __cplusplus
}  /* extern "C" */
#endif

#endif /* MOD_ACL_LOCALDB_H_ */
